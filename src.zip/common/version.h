#ifndef VERSION_H
#define VERSION_H

#define VERSION_STR "0.7.3"

#endif /* VERSION_H */
